/**
 ****************************************************************************************************
 * @file        main.c
 * @brief       TFTLCD GIF������ʾ��28֡��
 ****************************************************************************************************
 */

#include "./SYSTEM/sys/sys.h"
#include "./SYSTEM/usart/usart.h"
#include "./SYSTEM/delay/delay.h"
#include "./BSP/LED/led.h"
#include "./BSP/LCD/lcd.h"
#include "frames.h"

// ���������ʾλ�ã�LCD�ֱ���240��320��
#define IMAGE_POS_X  ((240 - FRAME_W) / 2)   // (240-72)/2 = 84
#define IMAGE_POS_Y  ((320 - FRAME_H) / 2)   // (320-78)/2 = 121

/**
 * @brief ��LCDָ��λ����ʾһ��RGB565ͼƬ
 */
void lcd_show_image(uint16_t x, uint16_t y, uint16_t w, uint16_t h, const uint16_t *img)
{
    uint32_t index = 0;
    
    for (uint16_t row = 0; row < h; row++) {
        for (uint16_t col = 0; col < w; col++) {
            lcd_draw_point(x + col, y + row, img[index++]);
        }
    }
}

int main(void)
{
    uint8_t frame_index = 0;
    
    HAL_Init();
    sys_stm32_clock_init(336, 8, 2, 7);
    delay_init(168);
    usart_init(115200);
    led_init();
    lcd_init();
    
    lcd_clear(WHITE);  // �ĳɰ�ɫ����
    
    while (1)
    {
        lcd_show_image(IMAGE_POS_X, IMAGE_POS_Y, FRAME_W, FRAME_H, frames[frame_index]);
        
        frame_index++;
        if (frame_index >= FRAME_COUNT) {
            frame_index = 0;
        }
        
        LED0_TOGGLE();
        delay_ms(100);
    }
}
