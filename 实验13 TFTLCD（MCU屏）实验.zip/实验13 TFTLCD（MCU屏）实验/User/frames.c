#include "frames.h"

#include "frame1.c"
#include "frame2.c"
#include "frame3.c"
#include "frame4.c"
#include "frame5.c"
#include "frame6.c"
#include "frame7.c"
#include "frame8.c"
#include "frame9.c"
#include "frame10.c"
#include "frame11.c"
#include "frame12.c"
#include "frame13.c"
#include "frame14.c"
#include "frame15.c"
#include "frame16.c"
#include "frame17.c"
#include "frame18.c"
#include "frame19.c"
#include "frame20.c"
#include "frame21.c"
#include "frame22.c"
#include "frame23.c"
#include "frame24.c"
#include "frame25.c"
#include "frame26.c"
#include "frame27.c"
#include "frame28.c"


const uint16_t *frames[FRAME_COUNT] = {
    frame1, frame2, frame3, frame4, frame5, frame6, frame7, frame8, frame9, frame10,
    frame11, frame12, frame13, frame14, frame15, frame16, frame17, frame18, frame19, frame20,
    frame21, frame22, frame23, frame24, frame25, frame26, frame27, frame28};
