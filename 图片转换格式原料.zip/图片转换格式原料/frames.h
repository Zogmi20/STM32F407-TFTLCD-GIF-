#ifndef __FRAMES_H
#define __FRAMES_H

#include <stdint.h>

#define FRAME_W  72
#define FRAME_H  78
#define FRAME_COUNT  28

extern const uint16_t frame1[5616];
extern const uint16_t frame2[5616];
extern const uint16_t frame3[5616];
extern const uint16_t frame4[5616];
extern const uint16_t frame5[5616];
extern const uint16_t frame6[5616];
extern const uint16_t frame7[5616];
extern const uint16_t frame8[5616];
extern const uint16_t frame9[5616];
extern const uint16_t frame10[5616];
extern const uint16_t frame11[5616];
extern const uint16_t frame12[5616];
extern const uint16_t frame13[5616];
extern const uint16_t frame14[5616];
extern const uint16_t frame15[5616];
extern const uint16_t frame16[5616];
extern const uint16_t frame17[5616];
extern const uint16_t frame18[5616];
extern const uint16_t frame19[5616];
extern const uint16_t frame20[5616];
extern const uint16_t frame21[5616];
extern const uint16_t frame22[5616];
extern const uint16_t frame23[5616];
extern const uint16_t frame24[5616];
extern const uint16_t frame25[5616];
extern const uint16_t frame26[5616];
extern const uint16_t frame27[5616];
extern const uint16_t frame28[5616];

// 帧指针数组
extern const uint16_t *frames[28];

#endif
